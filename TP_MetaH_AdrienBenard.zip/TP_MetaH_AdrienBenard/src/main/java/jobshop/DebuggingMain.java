package jobshop;

import jobshop.encodings.JobNumbers;
import java.io.IOException;
import java.nio.file.Paths;

public class DebuggingMain {

    public static void main(String[] args) {
        try {
            //Code To test

        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

    }
}