package jobshop.solvers;

import jobshop.Instance;
import jobshop.Result;
import jobshop.Schedule;
import jobshop.Solver;
import jobshop.encodings.ResourceOrder;
import jobshop.encodings.Task;

import java.util.*;

public class GreedySolver implements Solver {

    boolean earliestStartTimeMode;
    boolean crescentOrder;
    boolean remainingProcessingTimeMode;

    private static int getProcessingTime(Task task, Instance instance) {
        return instance.duration(task.job, task.task);
    }

    private static int getRemainingProcessingTime(Task task, Instance instance) {
        int remainingJobTime = 0;
        for (int i=task.task; i<instance.numTasks; i++) {
            remainingJobTime += instance.duration(task.job, i);
        }
        return remainingJobTime;
    }

    private Comparator<Task> getProcessingTimeComparator(Instance instance) {
        Comparator<Task> crescentCmp = Comparator.comparingInt((Task o) -> {
            if(remainingProcessingTimeMode) {
                return getRemainingProcessingTime(o, instance);
            } else {
                return getProcessingTime(o, instance);
            }
        });

        if(crescentOrder) {
            return crescentCmp;
        } else {
            return crescentCmp.reversed();
        }
    }

    private Comparator<Task> getComparator(ResourceOrder sol, int[][] times) {
        if(earliestStartTimeMode) {
            return (Task o1, Task o2) -> {
                int startDateCmp = Comparator.comparingInt((Task o) -> times[o.job][o.task]).compare(o1, o2);
                if(startDateCmp != 0) {
                    return startDateCmp;
                } else {
                    return getProcessingTimeComparator(sol.instance).compare(o1, o2);
                }
            };
        } else {
            return getProcessingTimeComparator(sol.instance);
        }
    }

    private static void setEarliestTaskStartDate(Task task, ResourceOrder sol, int[][] startTimes) {
        int taskRes = sol.instance.machine(task);
        Task previousTaskResource = null;
        if(sol.tasksOrderPerMachine[taskRes].size() > 0) {
            previousTaskResource = sol.tasksOrderPerMachine[taskRes].get(sol.tasksOrderPerMachine[taskRes].size() - 1);
        }
        Task previousTaskJob = task.getPreviousJobTask();

        if (previousTaskResource == null) {
            if (previousTaskJob == null) {
                startTimes[task.job][task.task] = 0;
            } else if (startTimes[previousTaskJob.job][previousTaskJob.task] != -1) {
                startTimes[task.job][task.task] = startTimes[previousTaskJob.job][previousTaskJob.task] + sol.instance.duration(previousTaskJob);
            }
        } else if (startTimes[previousTaskResource.job][previousTaskResource.task] != -1) {
            if (previousTaskJob == null) {
                startTimes[task.job][task.task] = startTimes[previousTaskResource.job][previousTaskResource.task] + sol.instance.duration(previousTaskResource);
            } else if (startTimes[previousTaskJob.job][previousTaskJob.task] != -1) {
                startTimes[task.job][task.task] = Integer.max(
                        startTimes[previousTaskJob.job][previousTaskJob.task] + sol.instance.duration(previousTaskJob),
                        startTimes[previousTaskResource.job][previousTaskResource.task] + sol.instance.duration(previousTaskResource)
                );
            }
        }
    }

    /**
     *
     * @param ispt detrtmine if PT
     * @param isrpt detrtmine if RPT
     * @param startwithshortest if true then S otherwise L coupled with other parameter determine the priority
     */
    public GreedySolver(boolean ispt, boolean isrpt, boolean startwithshortest) {
        this.earliestStartTimeMode = ispt;
        this.crescentOrder = startwithshortest;
        this.remainingProcessingTimeMode = isrpt;
    }

    @Override
    public Result solve(Instance instance, long deadline) {
        ResourceOrder sol = new ResourceOrder(instance);

        int[][] startTimes = null;
        if(earliestStartTimeMode) {
            startTimes = new int[instance.numJobs][instance.numTasks];
            for (int j = 0; j < instance.numJobs; j++) {
                Arrays.fill(startTimes[j], -1);
            }
        }

        Comparator<Task> comparator = this.getComparator(sol, startTimes);
        PriorityQueue<Task> realizableTasks = new PriorityQueue<Task>(instance.numJobs, comparator);

        for(int j=0; j<instance.numJobs; j++) {
            Task task = new Task(j, 0);
            if(earliestStartTimeMode) {
                setEarliestTaskStartDate(task, sol, startTimes);
            }
            realizableTasks.add(task);
        }

        while (!realizableTasks.isEmpty()) {

            Task chosenRealizableTask = realizableTasks.poll();

            int chosenRealizableTaskMachine = instance.machine(chosenRealizableTask);

            sol.addTaskToResourceQueue(chosenRealizableTaskMachine, chosenRealizableTask.task, chosenRealizableTask.job);

            if(earliestStartTimeMode) {
                ArrayList<Task> tasksToUpdate = new ArrayList<Task>(instance.numJobs);
                Iterator<Task> iter = realizableTasks.iterator();
                while(iter.hasNext()) {
                    Task currentTask = iter.next();
                    if(instance.machine(currentTask) == instance.machine(chosenRealizableTask)) {
                        setEarliestTaskStartDate(currentTask, sol, startTimes);
                        iter.remove();
                        tasksToUpdate.add(currentTask);
                    }
                }
                for(Task currentTask : tasksToUpdate) {
                    realizableTasks.add(currentTask);
                }
            }

            if(chosenRealizableTask.task+1 < instance.numTasks) {
                Task newRealizableTask = new Task(chosenRealizableTask.job, chosenRealizableTask.task + 1);
                if(earliestStartTimeMode) {
                    setEarliestTaskStartDate(newRealizableTask, sol, startTimes);

                }
                realizableTasks.add(newRealizableTask);
            }
        }

        Schedule returnedSched;
        if(earliestStartTimeMode) {
            returnedSched = new Schedule(instance, startTimes);
            assert returnedSched.equals(sol.toSchedule());
        } else {
            returnedSched = sol.toSchedule();
        }
        return new Result(instance, returnedSched, Result.ExitCause.Blocked);
    }
}
